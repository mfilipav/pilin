

  postscript ( 'dssp.ps', pointsize=12, paper='special', height=9, width=12 )
  #png ( width = 1024, height=768, file='dssp.png', pointsize=16 )
  
  par(bg='white')
  
  # DRAW PLOT IN LEFT WINDOW
  # margins for left window  (bottom, left, top, right)
  mar.orig <- (par.orig <- par(c('mar', 'las', 'mfrow')))$mar
  on.exit(par(par.orig))
  mar <- mar.orig
  mar[1] <- mar[1]
  mar[2] <- mar[2] + 1.0
  mar[4] <- 0.5
  par(mar=mar)

  layout ( matrix ( c(1,2), 1, 2, byrow=TRUE), widths=c(90,10))


  data <- read.table('dssp.histogram')
  residues = length(data[1,])
  x <- seq ( 1, 1 + residues - 2 )
  y <- data[,1]/1000
  matrix = array(data[,2:residues], dimnames=NULL)
  
  crs = c ( 'white','magenta','blue','cyan','forestgreen','forestgreen','firebrick','firebrick','goldenrod4','goldenrod4','green','green','darkorange','darkorange' ) 
  bks = c ( -100.0000,0.0000,1.0000,2.0000,3.0000,4.0000,5.0000,6.0000,7.0000,8.0000,9.0000,10.0000,11.0000,12.0000,13.0000 )

  y_shift = y+10/1000/2
  
  par (lwd=5)
  image ( x, 
          y_shift, 
          aperm(as.matrix(matrix)),
          col=crs, 
          breaks=bks, 
          xlab='Residue Number', 
          ylab='Time (ns)', 
          cex.main=2, 
          cex.axis=2, 
          cex.lab=2
        )


  image ( x, 
          y, 
          aperm(as.matrix(matrix)),
          col=crs, 
          breaks=bks, 
          xlab='Residue Number', 
          ylab='Time (ns)', 
          cex.main=2, 
          cex.axis=2, 
          cex.lab=2, 
          add=TRUE
        )
  # vertical residue lines
  abline ( v = c ( 1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5,13.5,14.5,15.5,16.5,17.5,18.5,19.5,20.5,21.5,22.5,23.5,24.5,25.5,26.5,27.5,28.5,29.5,30.5,31.5,32.5,33.5,34.5,35.5,36.5,37.5,38.5,39.5,40.5,41.5,42.5,43.5,44.5,45.5,46.5,47.5,48.5,49.5,50.5,51.5 ), col='black', lw=0.5 )

  # horizontal timepoint lines
  abline ( h = axTicks ( 2 ), col='black', lw=3, lty=3 )
  
  # top and bottom emphasis delimiters 
  abline ( h=0.0000/1000, lw=3 )
  abline ( h=5990.0000/1000, lw=3)
  title(main='/home1/03904/tg832040/lab5/ID3/310/1/dssp/1_ID3_A', outer=TRUE, line=-2.5, cex.main=2)


  # DRAW LEGEND IN RIGHT WINDOW
  
  par(lwd=2)
  mar <- mar.orig
  mar[1] <- 0.0
  mar[2] <- 0.0
  mar[3] <- 0.0
  mar[4] <- 0.0
  par(mar=mar)
  plot.new( )
  

  legend_values = c ( 'Loop','3/10\nHelix','Alpha\nHelix','Pi\nHelix','Alpha\nSheet','Beta\nSheet','Mixed\nSheet','Alpha\nBridge','Beta\nBridge' )
  legend_colors = c ( 'white','magenta','blue','cyan','forestgreen','firebrick','goldenrod4','green','darkorange')
  legend ( 'center', y=NULL, legend_values, fill=legend_colors, col='black', bg='#FFFFFF', bty='n', xjust=0.5, y.intersp=2.0, title='Secondary\nStructure' )
